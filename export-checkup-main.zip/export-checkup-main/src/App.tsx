import React from 'react';
import { useAssessment } from './hooks/useAssessment';
import { WelcomePage } from './components/WelcomePage';
import { CompanyDataForm } from './components/CompanyDataForm';
import { AssessmentForm } from './components/AssessmentForm';
import { ResultsPage } from './components/ResultsPage';
import { assessmentAreas } from './data/questions';

function App() {
  const {
    state,
    startAssessment,
    setCompanyData,
    setAnswer,
    nextArea,
    previousArea,
    completeAssessment,
    restart
  } = useAssessment();

  const renderCurrentStep = () => {
    switch (state.currentStep) {
      case 'welcome':
        return <WelcomePage onStart={startAssessment} />;
      
      case 'company-data':
        return (
          <CompanyDataForm
            onSubmit={setCompanyData}
            initialData={state.companyData}
          />
        );
      
      case 'assessment':
        return (
          <AssessmentForm
            areas={assessmentAreas}
            currentAreaIndex={state.currentAreaIndex}
            answers={state.answers}
            onAnswerChange={setAnswer}
            onNext={nextArea}
            onPrevious={previousArea}
            onComplete={completeAssessment}
            progress={state.progress}
          />
        );
      
      case 'results':
        return (
          <ResultsPage
            results={state.results!}
            companyData={state.companyData!}
            onRestart={restart}
          />
        );
      
      default:
        return <WelcomePage onStart={startAssessment} />;
    }
  };

  return (
    <div className="App">
      {renderCurrentStep()}
    </div>
  );
}

export default App;