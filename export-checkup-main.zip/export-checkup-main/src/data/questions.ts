import { AssessmentArea } from '../types';

export const assessmentAreas: AssessmentArea[] = [
  {
    id: 'prodotto-servizio',
    name: 'Prodotto/Servizio',
    description: 'Valutazione delle caratteristiche del prodotto/servizio e della sua adattabilità ai mercati esteri',
    maxScore: 10,
    questions: [
      {
        id: 'ps_1',
        text: 'Descrizione dettagliata dei prodotti/servizi offerti dalla vostra azienda',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'ps_2',
        text: 'Indicate le principali applicazioni dei vostri prodotti/servizi',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'ps_3',
        text: 'Quali sono i principali mercati di sbocco attuali?',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'ps_4',
        text: 'Valutate la qualità del packaging sviluppato per specifici mercati (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'ps_5',
        text: 'Valutate la conformità del packaging alle normative del Paese target (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'ps_6',
        text: 'Livello di certificazioni di sistema volontarie (ISO 9001, ISO 45001, ecc.) (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.1,
        required: true
      },
      {
        id: 'ps_7',
        text: 'Livello di certificazioni di qualità, ambientali o sociali per sostenibilità (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'ps_8',
        text: 'Livello di certificazioni obbligatorie per mercati specifici (FDA, EAC, ecc.) (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'ps_9',
        text: 'Livello di certificazioni di prodotto per settori specifici (Halal, Kosher, ecc.) (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.1,
        required: true
      },
      {
        id: 'ps_10',
        text: 'L\'azienda ha sviluppato nuovi prodotti/servizi per mercati esteri negli ultimi 3 anni?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'ps_11',
        text: 'Livello di adattamento prodotti/servizi per mercati esteri (non obbligatori) (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.1,
        required: true
      }
    ]
  },
  {
    id: 'mercati',
    name: 'Mercati',
    description: 'Analisi della conoscenza e presenza sui mercati internazionali',
    maxScore: 10,
    questions: [
      {
        id: 'm_1',
        text: 'Numero totale di clienti attivi',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'm_2',
        text: 'Segmentazione del fatturato per area geografica',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'm_3',
        text: 'Mercati attualmente presidiati (elenco Paesi)',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'm_4',
        text: 'Livello di conoscenza dei vincoli doganali nei mercati target (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.08,
        required: true
      },
      {
        id: 'm_5',
        text: 'Livello di conoscenza delle normative fiscali internazionali (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.08,
        required: true
      },
      {
        id: 'm_6',
        text: 'Livello di analisi della concorrenza sui mercati esteri (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.06,
        required: true
      },
      {
        id: 'm_7',
        text: 'Qualità dei contratti internazionali stipulati (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.07,
        required: true
      },
      {
        id: 'm_8',
        text: 'Efficacia della gestione dei pagamenti internazionali (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.08,
        required: true
      },
      {
        id: 'm_9',
        text: 'Utilizzo di strumenti per ricerca mercati/clienti (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.06,
        required: true
      },
      {
        id: 'm_10',
        text: 'Livello di diversificazione geografica del portafoglio clienti (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.05,
        required: true
      }
    ]
  },
  {
    id: 'strategie',
    name: 'Strategie',
    description: 'Valutazione delle strategie e pianificazione per l\'export',
    maxScore: 10,
    questions: [
      {
        id: 's_1',
        text: 'Percentuale del fatturato derivante da export',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 's_2',
        text: 'Esistono piani di sviluppo formalizzati per l\'export?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 's_3',
        text: 'Livello di protezione brevettuale dei prodotti (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 's_4',
        text: 'Qualità del budget formalizzato per attività export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 's_5',
        text: 'L\'azienda redige un bilancio di sostenibilità?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 's_6',
        text: 'Livello di accesso a finanziamenti per l\'export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.25,
        required: true
      },
      {
        id: 's_7',
        text: 'Utilizzo di strumenti di credito export (SACE, ecc.) (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 's_8',
        text: 'Livello di pianificazione strategica a medio-lungo termine (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      }
    ]
  },
  {
    id: 'risorse-umane',
    name: 'Risorse Umane',
    description: 'Analisi delle competenze e risorse dedicate all\'export',
    maxScore: 10,
    questions: [
      {
        id: 'ru_1',
        text: 'Numero totale di dipendenti',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'ru_2',
        text: 'Presenza di un Ufficio Export dedicato?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'ru_3',
        text: 'Utilizzo di consulenti esterni per l\'export?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'ru_4',
        text: 'Livello di competenze linguistiche del team (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'ru_5',
        text: 'Piani di sviluppo occupazionale per l\'export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'ru_6',
        text: 'Qualità dei piani di aggiornamento/formazione export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.25,
        required: true
      },
      {
        id: 'ru_7',
        text: 'Livello di esperienza del team export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.25,
        required: true
      },
      {
        id: 'ru_8',
        text: 'Efficacia della gestione delle relazioni internazionali (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      }
    ]
  },
  {
    id: 'processi',
    name: 'Processi',
    description: 'Valutazione dei processi aziendali orientati all\'export',
    maxScore: 10,
    questions: [
      {
        id: 'p_1',
        text: 'Utilizzo di sistemi CRM per gestione clienti internazionali?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'p_2',
        text: 'Percentuale di esportazione dei prodotti/servizi',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'p_3',
        text: 'Livello di implementazione Lean Production (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'p_4',
        text: 'Qualità delle politiche di acquisto sostenibili (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'p_5',
        text: 'Livello di collaborazione con Enti Terzi per export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'p_6',
        text: 'Utilizzo di indicatori di produttività (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'p_7',
        text: 'Efficacia dei processi di controllo qualità export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'p_8',
        text: 'Livello di digitalizzazione dei processi export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      }
    ]
  },
  {
    id: 'export-digitale',
    name: 'Export Digitale',
    description: 'Analisi delle competenze e strumenti digitali per l\'export',
    maxScore: 10,
    questions: [
      {
        id: 'ed_1',
        text: 'Livello di utilizzo di tecnologie digitali per export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'ed_2',
        text: 'Presenza di piattaforma e-commerce aziendale?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'ed_3',
        text: 'Utilizzo di Marketplace internazionali (Amazon, Alibaba, ecc.)?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'ed_4',
        text: 'Crescita fatturato tramite canali online negli ultimi 3 anni (%)',
        type: 'qualitative',
        category: 'text',
        required: true
      },
      {
        id: 'ed_5',
        text: 'Livello di competenze digital export management (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.25,
        required: true
      },
      {
        id: 'ed_6',
        text: 'Efficacia degli strumenti di analytics e tracking (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'ed_7',
        text: 'Livello di integrazione sistemi digitali interni (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.2,
        required: true
      },
      {
        id: 'ed_8',
        text: 'Qualità della customer experience digitale internazionale (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      }
    ]
  },
  {
    id: 'comunicazione',
    name: 'Comunicazione/Promozione',
    description: 'Valutazione delle strategie di comunicazione e promozione internazionale',
    maxScore: 10,
    questions: [
      {
        id: 'c_1',
        text: 'Il sito web aziendale è multilingua?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'c_2',
        text: 'Livello di adattamento del sito per mercati specifici (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'c_3',
        text: 'Efficacia dell\'utilizzo dei social media per export (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.1,
        required: true
      },
      {
        id: 'c_4',
        text: 'Qualità dei materiali promozionali per mercati target (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'c_5',
        text: 'Partecipazione a fiere internazionali negli ultimi 3 anni?',
        type: 'qualitative',
        category: 'boolean',
        required: true
      },
      {
        id: 'c_6',
        text: 'Budget annuale dedicato a fiere internazionali (€)',
        type: 'qualitative',
        category: 'text',
        required: false
      },
      {
        id: 'c_7',
        text: 'Efficacia delle strategie di PR internazionali (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.12,
        required: true
      },
      {
        id: 'c_8',
        text: 'Livello di brand awareness sui mercati esteri (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.18,
        required: true
      },
      {
        id: 'c_9',
        text: 'Qualità delle partnership con distributori locali (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      },
      {
        id: 'c_10',
        text: 'Efficacia del content marketing internazionale (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.1,
        required: true
      },
      {
        id: 'c_11',
        text: 'Livello di personalizzazione comunicazione per mercato (0-10)',
        type: 'quantitative',
        category: 'slider',
        weight: 0.15,
        required: true
      }
    ]
  }
];