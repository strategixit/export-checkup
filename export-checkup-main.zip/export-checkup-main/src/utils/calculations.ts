import { Answer, AssessmentArea, AssessmentResults } from '../types';

export const calculateAreaScore = (area: AssessmentArea, answers: Record<string, Answer>): number => {
  let totalScore = 0;
  let totalWeight = 0;

  area.questions.forEach(question => {
    const answer = answers[question.id];
    if (answer && question.type === 'quantitative' && question.weight) {
      const score = typeof answer.value === 'number' ? answer.value : 0;
      totalScore += score * question.weight;
      totalWeight += question.weight;
    }
  });

  return totalWeight > 0 ? (totalScore / totalWeight) : 0;
};

export const calculateOverallScore = (areaScores: Record<string, number>): number => {
  const scores = Object.values(areaScores);
  return scores.length > 0 ? scores.reduce((sum, score) => sum + score, 0) / scores.length : 0;
};

export const generateRecommendations = (areaScores: Record<string, number>): Record<string, string[]> => {
  const recommendations: Record<string, string[]> = {};

  Object.entries(areaScores).forEach(([areaId, score]) => {
    recommendations[areaId] = getRecommendationsForArea(areaId, score);
  });

  return recommendations;
};

const getRecommendationsForArea = (areaId: string, score: number): string[] => {
  const recommendationsMap: Record<string, Record<string, string[]>> = {
    'prodotto-servizio': {
      low: [
        'Investire nello sviluppo di packaging specifici per mercati target',
        'Ottenere certificazioni internazionali richieste dai mercati di destinazione',
        'Adattare prodotti/servizi alle specifiche normative locali',
        'Sviluppare nuove varianti di prodotto per mercati esteri'
      ],
      medium: [
        'Ampliare il portafoglio certificazioni per nuovi mercati',
        'Migliorare la conformità normativa dei packaging',
        'Investire in R&D per prodotti export-oriented'
      ],
      high: [
        'Mantenere l\'eccellenza nelle certificazioni',
        'Esplorare mercati di nicchia per prodotti specializzati',
        'Diventare benchmark di settore per qualità e conformità'
      ]
    },
    'mercati': {
      low: [
        'Condurre ricerche di mercato approfondite sui paesi target',
        'Formarsi sulle normative doganali e fiscali internazionali',
        'Sviluppare una strategia di analisi competitiva sistematica',
        'Implementare strumenti di gestione pagamenti internazionali'
      ],
      medium: [
        'Diversificare ulteriormente il portafoglio geografico',
        'Approfondire la conoscenza dei mercati già presidiati',
        'Migliorare la qualità dei contratti internazionali'
      ],
      high: [
        'Diventare leader di mercato nei paesi chiave',
        'Espandere in mercati emergenti ad alto potenziale',
        'Sviluppare partnership strategiche locali'
      ]
    },
    'strategie': {
      low: [
        'Sviluppare un piano strategico formalizzato per l\'export',
        'Allocare budget specifici per attività internazionali',
        'Esplorare strumenti di finanziamento export (SACE, ecc.)',
        'Proteggere la proprietà intellettuale sui mercati chiave'
      ],
      medium: [
        'Aumentare la percentuale di fatturato export',
        'Migliorare la pianificazione strategica a medio termine',
        'Ottimizzare l\'utilizzo degli strumenti finanziari disponibili'
      ],
      high: [
        'Diventare un\'azienda a vocazione prevalentemente internazionale',
        'Sviluppare strategie di acquisizione sui mercati esteri',
        'Creare un modello di business replicabile globalmente'
      ]
    },
    'risorse-umane': {
      low: [
        'Creare un ufficio export dedicato con personale specializzato',
        'Investire nella formazione linguistica del team',
        'Sviluppare competenze specifiche per l\'export',
        'Assumere consulenti esterni qualificati'
      ],
      medium: [
        'Ampliare il team export con profili senior',
        'Implementare programmi di formazione continua',
        'Migliorare la gestione delle relazioni internazionali'
      ],
      high: [
        'Diventare un centro di eccellenza per competenze export',
        'Sviluppare programmi di mentoring interno',
        'Creare un network internazionale di talenti'
      ]
    },
    'processi': {
      low: [
        'Implementare un sistema CRM per gestire clienti internazionali',
        'Digitalizzare i processi export principali',
        'Adottare metodologie Lean Production',
        'Sviluppare KPI specifici per l\'export'
      ],
      medium: [
        'Ottimizzare i processi di controllo qualità export',
        'Migliorare la collaborazione con enti terzi',
        'Implementare politiche di acquisto sostenibili'
      ],
      high: [
        'Diventare benchmark di settore per efficienza processi',
        'Sviluppare automazioni avanzate per l\'export',
        'Creare un modello operativo scalabile globalmente'
      ]
    },
    'export-digitale': {
      low: [
        'Sviluppare una piattaforma e-commerce per mercati internazionali',
        'Investire in competenze digital export management',
        'Utilizzare marketplace internazionali (Amazon, Alibaba)',
        'Implementare strumenti di analytics e tracking'
      ],
      medium: [
        'Migliorare l\'integrazione tra sistemi digitali interni',
        'Ottimizzare la customer experience digitale',
        'Ampliare la presenza sui marketplace internazionali'
      ],
      high: [
        'Diventare leader nell\'export digitale del settore',
        'Sviluppare tecnologie proprietarie per l\'export',
        'Creare ecosistemi digitali integrati per mercati globali'
      ]
    },
    'comunicazione': {
      low: [
        'Sviluppare un sito web multilingua professionale',
        'Creare materiali promozionali specifici per mercati target',
        'Partecipare a fiere internazionali del settore',
        'Implementare strategie social media internazionali'
      ],
      medium: [
        'Migliorare la brand awareness sui mercati esteri',
        'Sviluppare partnership con distributori locali',
        'Ottimizzare il content marketing internazionale'
      ],
      high: [
        'Diventare un brand riconosciuto globalmente',
        'Sviluppare strategie di thought leadership internazionale',
        'Creare comunità globali attorno al brand'
      ]
    }
  };

  const areaRecommendations = recommendationsMap[areaId];
  if (!areaRecommendations) return [];

  if (score < 4) return areaRecommendations.low || [];
  if (score < 7) return areaRecommendations.medium || [];
  return areaRecommendations.high || [];
};

export const getScoreDescription = (score: number): { level: string; description: string; color: string } => {
  if (score < 4) {
    return {
      level: 'Area di Miglioramento',
      description: 'Questa area richiede attenzione prioritaria e investimenti mirati per migliorare la propensione all\'export.',
      color: 'text-red-600'
    };
  }
  if (score < 7) {
    return {
      level: 'Livello Intermedio',
      description: 'Buone basi con margini di miglioramento. Sono necessari investimenti strategici per ottimizzare le performance.',
      color: 'text-yellow-600'
    };
  }
  return {
    level: 'Eccellenza',
    description: 'Area di forza dell\'azienda. Mantenere gli standard elevati e considerare opportunità di leadership di mercato.',
    color: 'text-green-600'
  };
};