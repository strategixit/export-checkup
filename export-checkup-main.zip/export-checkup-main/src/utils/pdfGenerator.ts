import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { CompanyData, AssessmentResults } from '../types';

export const generatePDF = async (
  element: HTMLElement,
  companyData: CompanyData,
  results: AssessmentResults
): Promise<void> => {
  try {
    // Create a new jsPDF instance
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 20;
    const contentWidth = pageWidth - (margin * 2);

    // Area icons mapping (using Unicode symbols for PDF compatibility)
    const areaIcons: Record<string, string> = {
      'prodotto-servizio': '📦',
      'mercati': '🌍',
      'strategie': '🎯',
      'risorse-umane': '👥',
      'processi': '⚙️',
      'export-digitale': '📱',
      'comunicazione': '💬'
    };

    // Helper function to add a new page with header
    const addPageWithHeader = () => {
      pdf.addPage();
      // Add subtle header line
      pdf.setDrawColor(59, 130, 246);
      pdf.setLineWidth(0.5);
      pdf.line(margin, 15, pageWidth - margin, 15);
      return 25; // Return starting Y position
    };

    // Helper function to check if we need a new page
    const checkPageBreak = (currentY: number, requiredSpace: number) => {
      if (currentY + requiredSpace > pageHeight - 30) {
        return addPageWithHeader();
      }
      return currentY;
    };

    // ===== PAGE 1: COVER PAGE =====
    // Background gradient effect
    pdf.setFillColor(239, 246, 255);
    pdf.rect(0, 0, pageWidth, pageHeight / 3, 'F');

    // Main title
    pdf.setFontSize(28);
    pdf.setTextColor(37, 99, 235);
    pdf.text('EXPORT ASSESSMENT', pageWidth / 2, 50, { align: 'center' });
    
    pdf.setFontSize(24);
    pdf.setTextColor(20, 184, 166);
    pdf.text('REPORT', pageWidth / 2, 65, { align: 'center' });

    // Company name
    pdf.setFontSize(20);
    pdf.setTextColor(17, 24, 39);
    pdf.text(companyData.ragioneSociale, pageWidth / 2, 90, { align: 'center' });

    // Decorative line
    pdf.setDrawColor(59, 130, 246);
    pdf.setLineWidth(2);
    pdf.line(pageWidth / 2 - 40, 100, pageWidth / 2 + 40, 100);

    // Overall score highlight
    pdf.setFillColor(37, 99, 235);
    pdf.roundedRect(pageWidth / 2 - 35, 120, 70, 40, 8, 8, 'F');
    
    pdf.setFontSize(32);
    pdf.setTextColor(255, 255, 255);
    pdf.text(`${results.overallScore.toFixed(1)}`, pageWidth / 2, 140, { align: 'center' });
    
    pdf.setFontSize(12);
    pdf.text('PUNTEGGIO COMPLESSIVO', pageWidth / 2, 150, { align: 'center' });

    // Date and details
    pdf.setFontSize(12);
    pdf.setTextColor(107, 114, 128);
    pdf.text(`Data Assessment: ${results.completionDate.toLocaleDateString('it-IT', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })}`, pageWidth / 2, 180, { align: 'center' });

    // Company details box
    pdf.setFillColor(248, 250, 252);
    pdf.setDrawColor(226, 232, 240);
    pdf.roundedRect(margin, 200, contentWidth, 60, 5, 5, 'FD');
    
    pdf.setFontSize(14);
    pdf.setTextColor(17, 24, 39);
    pdf.text('INFORMAZIONI AZIENDALI', margin + 10, 215);
    
    pdf.setFontSize(10);
    pdf.setTextColor(75, 85, 99);
    let detailY = 225;
    pdf.text(`P.IVA: ${companyData.partitaIva}`, margin + 10, detailY);
    pdf.text(`Dimensione: ${companyData.dimensioneAzienda} impresa`, margin + 10, detailY + 8);
    if (companyData.fatturatoAnnuo) {
      pdf.text(`Fatturato: €${companyData.fatturatoAnnuo.toLocaleString()}`, margin + 10, detailY + 16);
    }
    if (companyData.numeroDipendenti) {
      pdf.text(`Dipendenti: ${companyData.numeroDipendenti}`, margin + 10, detailY + 24);
    }

    // Footer
    pdf.setFontSize(8);
    pdf.setTextColor(156, 163, 175);
    pdf.text('Export Assessment Report - Analisi della Propensione all\'Export', pageWidth / 2, pageHeight - 15, { align: 'center' });

    // ===== PAGE 2: EXECUTIVE SUMMARY =====
    let yPos = addPageWithHeader();
    
    pdf.setFontSize(20);
    pdf.setTextColor(17, 24, 39);
    pdf.text('EXECUTIVE SUMMARY', margin, yPos);
    yPos += 20;

    // Overall assessment
    const getOverallAssessment = (score: number) => {
      if (score >= 8) return { level: 'ECCELLENTE', color: [34, 197, 94], description: 'L\'azienda dimostra un\'eccellente propensione all\'export con competenze avanzate in tutte le aree chiave.' };
      if (score >= 6) return { level: 'BUONO', color: [59, 130, 246], description: 'L\'azienda ha una buona base per l\'export con alcune aree che necessitano di miglioramenti mirati.' };
      if (score >= 4) return { level: 'DISCRETO', color: [245, 158, 11], description: 'L\'azienda presenta potenziale per l\'export ma richiede investimenti significativi in diverse aree.' };
      return { level: 'DA MIGLIORARE', color: [239, 68, 68], description: 'L\'azienda necessita di un piano di sviluppo strutturato per migliorare la propensione all\'export.' };
    };

    const assessment = getOverallAssessment(results.overallScore);
    
    pdf.setFillColor(...assessment.color, 0.1 * 255);
    pdf.roundedRect(margin, yPos, contentWidth, 25, 5, 5, 'F');
    
    pdf.setFontSize(16);
    pdf.setTextColor(...assessment.color);
    pdf.text(`VALUTAZIONE: ${assessment.level}`, margin + 10, yPos + 15);
    yPos += 35;

    pdf.setFontSize(11);
    pdf.setTextColor(75, 85, 99);
    const summaryLines = pdf.splitTextToSize(assessment.description, contentWidth);
    pdf.text(summaryLines, margin, yPos);
    yPos += summaryLines.length * 6 + 15;

    // Key findings
    pdf.setFontSize(14);
    pdf.setTextColor(17, 24, 39);
    pdf.text('PRINCIPALI EVIDENZE', margin, yPos);
    yPos += 15;

    const areaNames: Record<string, string> = {
      'prodotto-servizio': 'Prodotto/Servizio',
      'mercati': 'Mercati',
      'strategie': 'Strategie',
      'risorse-umane': 'Risorse Umane',
      'processi': 'Processi',
      'export-digitale': 'Export Digitale',
      'comunicazione': 'Comunicazione/Promozione'
    };

    // Top 3 strengths and weaknesses
    const sortedAreas = Object.entries(results.areaScores).sort(([,a], [,b]) => b - a);
    const strengths = sortedAreas.slice(0, 3);
    const weaknesses = sortedAreas.slice(-3).reverse();

    // Strengths
    pdf.setFontSize(12);
    pdf.setTextColor(34, 197, 94);
    pdf.text('✓ PUNTI DI FORZA:', margin, yPos);
    yPos += 10;

    pdf.setFontSize(10);
    pdf.setTextColor(75, 85, 99);
    strengths.forEach(([areaId, score]) => {
      const icon = areaIcons[areaId] || '•';
      pdf.text(`${icon} ${areaNames[areaId]}: ${score.toFixed(1)}/10`, margin + 5, yPos);
      yPos += 8;
    });
    yPos += 5;

    // Weaknesses
    pdf.setFontSize(12);
    pdf.setTextColor(239, 68, 68);
    pdf.text('⚠ AREE DI MIGLIORAMENTO:', margin, yPos);
    yPos += 10;

    pdf.setFontSize(10);
    pdf.setTextColor(75, 85, 99);
    weaknesses.forEach(([areaId, score]) => {
      const icon = areaIcons[areaId] || '•';
      pdf.text(`${icon} ${areaNames[areaId]}: ${score.toFixed(1)}/10`, margin + 5, yPos);
      yPos += 8;
    });

    // ===== PAGE 3: RADAR CHART =====
    yPos = addPageWithHeader();
    
    pdf.setFontSize(20);
    pdf.setTextColor(17, 24, 39);
    pdf.text('ANALISI RADAR', margin, yPos);
    yPos += 20;

    // Create radar chart canvas
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      // Draw radar chart
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = 150;
      const areas = Object.keys(results.areaScores);
      const scores = Object.values(results.areaScores);
      
      // Clear canvas
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Draw grid circles
      ctx.strokeStyle = '#e5e7eb';
      ctx.lineWidth = 1;
      for (let i = 1; i <= 5; i++) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, (radius * i) / 5, 0, 2 * Math.PI);
        ctx.stroke();
      }
      
      // Draw axes
      ctx.strokeStyle = '#d1d5db';
      ctx.lineWidth = 1;
      areas.forEach((_, index) => {
        const angle = (index * 2 * Math.PI) / areas.length - Math.PI / 2;
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;
        
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(x, y);
        ctx.stroke();
      });
      
      // Draw data polygon
      ctx.fillStyle = 'rgba(59, 130, 246, 0.2)';
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 3;
      
      ctx.beginPath();
      scores.forEach((score, index) => {
        const angle = (index * 2 * Math.PI) / areas.length - Math.PI / 2;
        const distance = (score / 10) * radius;
        const x = centerX + Math.cos(angle) * distance;
        const y = centerY + Math.sin(angle) * distance;
        
        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      
      // Draw points
      ctx.fillStyle = '#3b82f6';
      scores.forEach((score, index) => {
        const angle = (index * 2 * Math.PI) / areas.length - Math.PI / 2;
        const distance = (score / 10) * radius;
        const x = centerX + Math.cos(angle) * distance;
        const y = centerY + Math.sin(angle) * distance;
        
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, 2 * Math.PI);
        ctx.fill();
      });
      
      // Draw labels with icons
      ctx.fillStyle = '#374151';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      areas.forEach((areaId, index) => {
        const angle = (index * 2 * Math.PI) / areas.length - Math.PI / 2;
        const labelDistance = radius + 30;
        const x = centerX + Math.cos(angle) * labelDistance;
        const y = centerY + Math.sin(angle) * labelDistance;
        
        const areaName = areaNames[areaId] || areaId;
        const icon = areaIcons[areaId] || '';
        
        // Draw icon
        ctx.font = '20px Arial';
        ctx.fillText(icon, x, y - 15);
        
        // Draw text
        ctx.font = 'bold 12px Arial';
        const words = areaName.split(' ');
        if (words.length > 1) {
          ctx.fillText(words[0], x, y + 5);
          ctx.fillText(words.slice(1).join(' '), x, y + 18);
        } else {
          ctx.fillText(areaName, x, y + 10);
        }
      });
      
      // Convert canvas to image and add to PDF
      const radarImageData = canvas.toDataURL('image/png');
      const imgWidth = 120;
      const imgHeight = 120;
      const imgX = (pageWidth - imgWidth) / 2;
      
      pdf.addImage(radarImageData, 'PNG', imgX, yPos, imgWidth, imgHeight);
      yPos += imgHeight + 20;
    }

    // Legend with icons
    pdf.setFontSize(12);
    pdf.setTextColor(17, 24, 39);
    pdf.text('LEGENDA PUNTEGGI', margin, yPos);
    yPos += 15;

    pdf.setFontSize(10);
    Object.entries(results.areaScores).forEach(([areaId, score]) => {
      yPos = checkPageBreak(yPos, 10);
      
      // Color indicator
      const color = score >= 7 ? [34, 197, 94] : score >= 4 ? [245, 158, 11] : [239, 68, 68];
      pdf.setFillColor(...color);
      pdf.circle(margin + 3, yPos - 2, 2, 'F');
      
      // Icon and text
      const icon = areaIcons[areaId] || '•';
      pdf.setTextColor(75, 85, 99);
      pdf.text(`${icon} ${areaNames[areaId]}: ${score.toFixed(1)}/10`, margin + 10, yPos);
      yPos += 8;
    });

    // ===== PAGE 4+: DETAILED AREA ANALYSIS =====
    Object.entries(results.areaScores).forEach(([areaId, score]) => {
      yPos = addPageWithHeader();
      
      // Area title with icon
      const icon = areaIcons[areaId] || '';
      pdf.setFontSize(18);
      pdf.setTextColor(17, 24, 39);
      pdf.text(`${icon} ${areaNames[areaId].toUpperCase()}`, margin, yPos);
      yPos += 15;

      // Score box
      const scoreColor = score >= 7 ? [34, 197, 94] : score >= 4 ? [245, 158, 11] : [239, 68, 68];
      pdf.setFillColor(...scoreColor, 0.1 * 255);
      pdf.setDrawColor(...scoreColor);
      pdf.roundedRect(margin, yPos, 60, 20, 3, 3, 'FD');
      
      pdf.setFontSize(16);
      pdf.setTextColor(...scoreColor);
      pdf.text(`${score.toFixed(1)}/10`, margin + 30, yPos + 13, { align: 'center' });
      yPos += 30;

      // Description
      const getScoreDescription = (score: number) => {
        if (score >= 7) return 'ECCELLENTE - Area di forza dell\'azienda con performance superiori alla media.';
        if (score >= 4) return 'BUONO - Prestazioni soddisfacenti con margini di miglioramento.';
        return 'DA MIGLIORARE - Area che richiede attenzione prioritaria e investimenti mirati.';
      };

      pdf.setFontSize(11);
      pdf.setTextColor(75, 85, 99);
      const descLines = pdf.splitTextToSize(getScoreDescription(score), contentWidth);
      pdf.text(descLines, margin, yPos);
      yPos += descLines.length * 6 + 15;

      // Recommendations
      const recommendations = results.recommendations[areaId] || [];
      if (recommendations.length > 0) {
        pdf.setFontSize(14);
        pdf.setTextColor(17, 24, 39);
        pdf.text('RACCOMANDAZIONI', margin, yPos);
        yPos += 15;

        pdf.setFontSize(10);
        pdf.setTextColor(75, 85, 99);
        recommendations.forEach((rec, index) => {
          yPos = checkPageBreak(yPos, 15);
          
          const recLines = pdf.splitTextToSize(`${index + 1}. ${rec}`, contentWidth - 10);
          pdf.text(recLines, margin + 5, yPos);
          yPos += recLines.length * 5 + 8;
        });
      }
    });

    // ===== FINAL PAGE: NEXT STEPS =====
    yPos = addPageWithHeader();
    
    pdf.setFontSize(20);
    pdf.setTextColor(17, 24, 39);
    pdf.text('🎯 PROSSIMI PASSI', margin, yPos);
    yPos += 20;

    pdf.setFontSize(12);
    pdf.setTextColor(75, 85, 99);
    const nextSteps = [
      'Analizzare in dettaglio le aree con punteggio inferiore a 6/10',
      'Sviluppare un piano d\'azione prioritizzato per le aree di miglioramento',
      'Allocare risorse e budget per implementare le raccomandazioni',
      'Stabilire KPI e metriche per monitorare i progressi',
      'Ripetere l\'assessment dopo 6-12 mesi per valutare i miglioramenti'
    ];

    const stepIcons = ['🔍', '📋', '💰', '📊', '🔄'];

    nextSteps.forEach((step, index) => {
      yPos = checkPageBreak(yPos, 15);
      const stepLines = pdf.splitTextToSize(`${stepIcons[index]} ${index + 1}. ${step}`, contentWidth - 10);
      pdf.text(stepLines, margin + 5, yPos);
      yPos += stepLines.length * 5 + 10;
    });

    // Footer with contact info
    yPos = pageHeight - 40;
    pdf.setFillColor(248, 250, 252);
    pdf.rect(margin, yPos, contentWidth, 25, 'F');
    
    pdf.setFontSize(10);
    pdf.setTextColor(107, 114, 128);
    pdf.text('📧 Per supporto nell\'implementazione delle raccomandazioni, contattare il team Export Assessment.', margin + 5, yPos + 15);

    // Save the PDF
    pdf.save(`Export_Assessment_${companyData.ragioneSociale.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
  } catch (error) {
    console.error('Error generating PDF:', error);
    alert('Errore durante la generazione del PDF. Riprova.');
  }
};