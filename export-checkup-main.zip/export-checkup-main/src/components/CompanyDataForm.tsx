import React, { useState } from 'react';
import { CompanyData } from '../types';
import { Building2, MapPin, Users, TrendingUp, ArrowRight, Plus, X } from 'lucide-react';

interface CompanyDataFormProps {
  onSubmit: (data: CompanyData) => void;
  initialData?: CompanyData | null;
}

export const CompanyDataForm: React.FC<CompanyDataFormProps> = ({ onSubmit, initialData }) => {
  const [formData, setFormData] = useState<CompanyData>(initialData || {
    ragioneSociale: '',
    partitaIva: '',
    indirizzo: '',
    dimensioneAzienda: 'piccola',
    fatturatoAnnuo: undefined,
    numeroDipendenti: undefined,
    numeroPaesiExport: undefined,
    paesiExport: []
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [newCountry, setNewCountry] = useState('');

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.ragioneSociale.trim()) {
      newErrors.ragioneSociale = 'La ragione sociale è obbligatoria';
    }

    if (!formData.partitaIva.trim()) {
      newErrors.partitaIva = 'La partita IVA è obbligatoria';
    } else if (!/^[0-9]{11}$/.test(formData.partitaIva.replace(/\s/g, ''))) {
      newErrors.partitaIva = 'La partita IVA deve contenere 11 cifre';
    }

    if (!formData.indirizzo.trim()) {
      newErrors.indirizzo = 'L\'indirizzo è obbligatorio';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const addCountry = () => {
    if (newCountry.trim() && !formData.paesiExport?.includes(newCountry.trim())) {
      setFormData(prev => ({
        ...prev,
        paesiExport: [...(prev.paesiExport || []), newCountry.trim()]
      }));
      setNewCountry('');
    }
  };

  const removeCountry = (country: string) => {
    setFormData(prev => ({
      ...prev,
      paesiExport: prev.paesiExport?.filter(c => c !== country) || []
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl flex items-center justify-center">
              <Building2 className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Dati Aziendali</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Inserisci le informazioni della tua azienda per personalizzare l'assessment e ottenere 
            raccomandazioni specifiche per il tuo contesto business
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 lg:p-12">
          <div className="space-y-8">
            {/* Required Fields Section */}
            <div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                <span className="w-2 h-2 bg-red-500 rounded-full mr-3"></span>
                Informazioni Obbligatorie
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Ragione Sociale *
                  </label>
                  <input
                    type="text"
                    value={formData.ragioneSociale}
                    onChange={(e) => setFormData(prev => ({ ...prev, ragioneSociale: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-xl border ${errors.ragioneSociale ? 'border-red-300' : 'border-gray-300'} focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                    placeholder="Inserisci la ragione sociale"
                  />
                  {errors.ragioneSociale && <p className="text-red-500 text-sm mt-1">{errors.ragioneSociale}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Partita IVA *
                  </label>
                  <input
                    type="text"
                    value={formData.partitaIva}
                    onChange={(e) => setFormData(prev => ({ ...prev, partitaIva: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-xl border ${errors.partitaIva ? 'border-red-300' : 'border-gray-300'} focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                    placeholder="12345678901"
                  />
                  {errors.partitaIva && <p className="text-red-500 text-sm mt-1">{errors.partitaIva}</p>}
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Indirizzo *
                  </label>
                  <input
                    type="text"
                    value={formData.indirizzo}
                    onChange={(e) => setFormData(prev => ({ ...prev, indirizzo: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-xl border ${errors.indirizzo ? 'border-red-300' : 'border-gray-300'} focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
                    placeholder="Via/Piazza, Numero, Città, Provincia"
                  />
                  {errors.indirizzo && <p className="text-red-500 text-sm mt-1">{errors.indirizzo}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Dimensione Azienda *
                  </label>
                  <select
                    value={formData.dimensioneAzienda}
                    onChange={(e) => setFormData(prev => ({ ...prev, dimensioneAzienda: e.target.value as CompanyData['dimensioneAzienda'] }))}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  >
                    <option value="micro">Microimpresa (&lt; 10 dipendenti)</option>
                    <option value="piccola">Piccola Impresa (10-49 dipendenti)</option>
                    <option value="media">Media Impresa (50-249 dipendenti)</option>
                    <option value="grande">Grande Impresa (250+ dipendenti)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Optional Fields Section */}
            <div className="border-t border-gray-200 pt-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-3"></span>
                Informazioni Aggiuntive (Facoltative)
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Fatturato Annuo (€)
                  </label>
                  <input
                    type="number"
                    value={formData.fatturatoAnnuo || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, fatturatoAnnuo: e.target.value ? Number(e.target.value) : undefined }))}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Es. 1000000"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Numero Dipendenti
                  </label>
                  <input
                    type="number"
                    value={formData.numeroDipendenti || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, numeroDipendenti: e.target.value ? Number(e.target.value) : undefined }))}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Es. 25"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Numero Paesi di Export
                  </label>
                  <input
                    type="number"
                    value={formData.numeroPaesiExport || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, numeroPaesiExport: e.target.value ? Number(e.target.value) : undefined }))}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Es. 5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Aggiungi Paese di Export
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={newCountry}
                      onChange={(e) => setNewCountry(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCountry())}
                      className="flex-1 px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="Es. Germania"
                    />
                    <button
                      type="button"
                      onClick={addCountry}
                      className="px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {formData.paesiExport && formData.paesiExport.length > 0 && (
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-3">
                      Paesi di Export Aggiunti
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {formData.paesiExport.map((country, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                        >
                          {country}
                          <button
                            type="button"
                            onClick={() => removeCountry(country)}
                            className="ml-2 hover:text-blue-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="mt-12 text-center">
            <button
              type="submit"
              className="group bg-gradient-to-r from-blue-600 to-teal-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:from-blue-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 inline-flex items-center space-x-3"
            >
              <span>Inizia Assessment</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};