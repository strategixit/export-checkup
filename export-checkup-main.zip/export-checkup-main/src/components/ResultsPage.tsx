import React, { useRef } from 'react';
import { AssessmentResults, CompanyData } from '../types';
import { Download, Award, TrendingUp, Target, AlertTriangle } from 'lucide-react';
import { RadarChart } from './RadarChart';
import { generatePDF } from '../utils/pdfGenerator';
import { getScoreDescription } from '../utils/calculations';

interface ResultsPageProps {
  results: AssessmentResults;
  companyData: CompanyData;
  onRestart: () => void;
}

export const ResultsPage: React.FC<ResultsPageProps> = ({ results, companyData, onRestart }) => {
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleDownloadPDF = async () => {
    if (resultsRef.current) {
      await generatePDF(resultsRef.current, companyData, results);
    }
  };

  const getOverallAssessment = (score: number) => {
    if (score >= 8) return { level: 'Eccellente', color: 'text-green-600', icon: Award };
    if (score >= 6) return { level: 'Buono', color: 'text-blue-600', icon: TrendingUp };
    if (score >= 4) return { level: 'Discreto', color: 'text-yellow-600', icon: Target };
    return { level: 'Da Migliorare', color: 'text-red-600', icon: AlertTriangle };
  };

  const overall = getOverallAssessment(results.overallScore);
  const OverallIcon = overall.icon;

  const areaNames: Record<string, string> = {
    'prodotto-servizio': 'Prodotto/Servizio',
    'mercati': 'Mercati',
    'strategie': 'Strategie',
    'risorse-umane': 'Risorse Umane',
    'processi': 'Processi',
    'export-digitale': 'Export Digitale',
    'comunicazione': 'Comunicazione/Promozione'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className={`w-20 h-20 rounded-3xl flex items-center justify-center ${
              overall.level === 'Eccellente' ? 'bg-green-100' :
              overall.level === 'Buono' ? 'bg-blue-100' :
              overall.level === 'Discreto' ? 'bg-yellow-100' : 'bg-red-100'
            }`}>
              <OverallIcon className={`w-10 h-10 ${overall.color}`} />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Report Assessment Export</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Analisi completa della propensione all'export per <strong>{companyData.ragioneSociale}</strong>
          </p>
          <div className="mt-6">
            <button
              onClick={handleDownloadPDF}
              className="group bg-gradient-to-r from-blue-600 to-teal-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 inline-flex items-center space-x-3"
            >
              <Download className="w-5 h-5" />
              <span>Scarica Report PDF</span>
            </button>
          </div>
        </div>

        {/* Results Content */}
        <div ref={resultsRef} className="space-y-8">
          {/* Overall Score Card */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 lg:p-12">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Punteggio Complessivo</h2>
              <div className="flex items-center justify-center space-x-6">
                <div className={`text-6xl font-bold ${overall.color}`}>
                  {results.overallScore.toFixed(1)}
                </div>
                <div className="text-left">
                  <div className={`text-2xl font-semibold ${overall.color}`}>
                    {overall.level}
                  </div>
                  <div className="text-gray-600">su 10.0</div>
                </div>
              </div>
              <div className="max-w-2xl mx-auto mt-6">
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className={`h-3 rounded-full transition-all duration-1000 ${
                      overall.level === 'Eccellente' ? 'bg-green-500' :
                      overall.level === 'Buono' ? 'bg-blue-500' :
                      overall.level === 'Discreto' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(results.overallScore / 10) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* Radar Chart */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 lg:p-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Analisi per Aree di Competenza
            </h3>
            <div className="max-w-2xl mx-auto">
              <RadarChart areaScores={results.areaScores} areaNames={areaNames} />
            </div>
          </div>

          {/* Area Scores Detail */}
          <div className="grid lg:grid-cols-2 gap-8">
            {Object.entries(results.areaScores).map(([areaId, score]) => {
              const description = getScoreDescription(score);
              const recommendations = results.recommendations[areaId] || [];
              
              return (
                <div key={areaId} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-xl font-semibold text-gray-900">
                      {areaNames[areaId]}
                    </h4>
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${description.color}`}>
                        {score.toFixed(1)}
                      </div>
                      <div className="text-sm text-gray-500">su 10.0</div>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-1000 ${
                          score >= 7 ? 'bg-green-500' :
                          score >= 4 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${(score / 10) * 100}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className={`mb-4 p-3 rounded-lg ${
                    score >= 7 ? 'bg-green-50' :
                    score >= 4 ? 'bg-yellow-50' : 'bg-red-50'
                  }`}>
                    <div className={`font-semibold mb-2 ${description.color}`}>
                      {description.level}
                    </div>
                    <p className="text-sm text-gray-700">
                      {description.description}
                    </p>
                  </div>

                  {recommendations.length > 0 && (
                    <div>
                      <h5 className="font-semibold text-gray-900 mb-2">Raccomandazioni:</h5>
                      <ul className="text-sm text-gray-700 space-y-1">
                        {recommendations.slice(0, 3).map((rec, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <span className="text-blue-600 font-bold mt-1">•</span>
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Company Information */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Informazioni Aziendali</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Ragione Sociale</label>
                <p className="text-lg font-semibold text-gray-900">{companyData.ragioneSociale}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Partita IVA</label>
                <p className="text-lg font-semibold text-gray-900">{companyData.partitaIva}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Dimensione</label>
                <p className="text-lg font-semibold text-gray-900 capitalize">{companyData.dimensioneAzienda} Impresa</p>
              </div>
              {companyData.fatturatoAnnuo && (
                <div>
                  <label className="block text-sm font-medium text-gray-500 mb-1">Fatturato Annuo</label>
                  <p className="text-lg font-semibold text-gray-900">€ {companyData.fatturatoAnnuo.toLocaleString()}</p>
                </div>
              )}
              {companyData.numeroDipendenti && (
                <div>
                  <label className="block text-sm font-medium text-gray-500 mb-1">Dipendenti</label>
                  <p className="text-lg font-semibold text-gray-900">{companyData.numeroDipendenti}</p>
                </div>
              )}
              {companyData.numeroPaesiExport && (
                <div>
                  <label className="block text-sm font-medium text-gray-500 mb-1">Paesi di Export</label>
                  <p className="text-lg font-semibold text-gray-900">{companyData.numeroPaesiExport}</p>
                </div>
              )}
            </div>
            {companyData.paesiExport && companyData.paesiExport.length > 0 && (
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-500 mb-2">Mercati Attuali</label>
                <div className="flex flex-wrap gap-2">
                  {companyData.paesiExport.map((country, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800 font-medium"
                    >
                      {country}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Completion Info */}
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Assessment Completato</h3>
            <p className="text-lg opacity-90 mb-6">
              Data di completamento: {results.completionDate.toLocaleDateString('it-IT', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </p>
            <button
              onClick={onRestart}
              className="bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-blue-50 transition-all duration-300 transform hover:scale-105"
            >
              Nuovo Assessment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};