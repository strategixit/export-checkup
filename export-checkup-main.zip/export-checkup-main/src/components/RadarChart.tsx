import React, { useEffect, useRef } from 'react';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { Radar } from 'react-chartjs-2';

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

interface RadarChartProps {
  areaScores: Record<string, number>;
  areaNames: Record<string, string>;
}

export const RadarChart: React.FC<RadarChartProps> = ({ areaScores, areaNames }) => {
  const chartRef = useRef<ChartJS<'radar'>>(null);

  const data = {
    labels: Object.keys(areaScores).map(key => areaNames[key] || key),
    datasets: [
      {
        label: 'Punteggio',
        data: Object.values(areaScores),
        borderColor: 'rgb(37, 99, 235)',
        backgroundColor: 'rgba(37, 99, 235, 0.2)',
        borderWidth: 3,
        pointBackgroundColor: 'rgb(37, 99, 235)',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(17, 24, 39, 0.9)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: 'rgba(37, 99, 235, 0.8)',
        borderWidth: 1,
        cornerRadius: 8,
        displayColors: false,
        callbacks: {
          label: function(context: any) {
            return `Punteggio: ${context.parsed.r.toFixed(1)}/10`;
          }
        }
      },
    },
    scales: {
      r: {
        beginAtZero: true,
        max: 10,
        min: 0,
        ticks: {
          stepSize: 2,
          color: '#6B7280',
          font: {
            size: 12,
          },
          callback: function(value: any) {
            return value.toString();
          }
        },
        grid: {
          color: 'rgba(107, 114, 128, 0.3)',
          lineWidth: 1,
        },
        angleLines: {
          color: 'rgba(107, 114, 128, 0.3)',
          lineWidth: 1,
        },
        pointLabels: {
          color: '#374151',
          font: {
            size: 13,
            weight: '600' as const,
          },
          padding: 20,
        },
      },
    },
    animation: {
      duration: 1500,
      easing: 'easeOutQuart' as const,
    },
  };

  return (
    <div className="relative h-96 w-full">
      <Radar ref={chartRef} data={data} options={options} />
    </div>
  );
};