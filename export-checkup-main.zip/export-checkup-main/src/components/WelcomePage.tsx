import React from 'react';
import { ArrowRight, BarChart3, Globe, Target, TrendingUp, CheckCircle, Users, Cog, Smartphone, MessageSquare, Package, MapPin } from 'lucide-react';

interface WelcomePageProps {
  onStart: () => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({ onStart }) => {
  const assessmentFeatures = [
    'Questionario strutturato in 7 ambiti di indagine',
    '85 domande approfondite (29 qualitative + 56 quantitative)',
    'Calcolo automatico dei punteggi ponderati',
    'Grafico radar per visualizzazione immediata',
    'Report PDF scaricabile e condivisibile',
    'Raccomandazioni personalizzate per ogni ambito'
  ];

  const assessmentAreas = [
    {
      name: 'Prodotto/Servizio',
      icon: Package,
      color: 'bg-blue-100 text-blue-600',
      questions: 11,
      description: 'Valutazione delle caratteristiche del prodotto/servizio e della sua adattabilità ai mercati esteri'
    },
    {
      name: 'Mercati',
      icon: MapPin,
      color: 'bg-green-100 text-green-600',
      questions: 25,
      description: 'Analisi della conoscenza e presenza sui mercati internazionali'
    },
    {
      name: 'Strategie',
      icon: Target,
      color: 'bg-purple-100 text-purple-600',
      questions: 8,
      description: 'Valutazione delle strategie e pianificazione per l\'export'
    },
    {
      name: 'Risorse Umane',
      icon: Users,
      color: 'bg-orange-100 text-orange-600',
      questions: 10,
      description: 'Analisi delle competenze e risorse dedicate all\'export'
    },
    {
      name: 'Processi',
      icon: Cog,
      color: 'bg-teal-100 text-teal-600',
      questions: 10,
      description: 'Valutazione dei processi aziendali orientati all\'export'
    },
    {
      name: 'Export Digitale',
      icon: Smartphone,
      color: 'bg-indigo-100 text-indigo-600',
      questions: 8,
      description: 'Analisi delle competenze e strumenti digitali per l\'export'
    },
    {
      name: 'Comunicazione/Promozione',
      icon: MessageSquare,
      color: 'bg-pink-100 text-pink-600',
      questions: 13,
      description: 'Valutazione delle strategie di comunicazione e promozione internazionale'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Header */}
      <header className="relative overflow-hidden bg-white/80 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl flex items-center justify-center">
                  <Globe className="w-7 h-7 text-white" />
                </div>
                <h1 className="text-3xl font-bold text-gray-900">Export Assessment</h1>
              </div>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Valuta la propensione all'export della tua azienda attraverso un audit strutturato 
              e ricevi raccomandazioni personalizzate per il successo sui mercati internazionali
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <div className="text-center mb-20">
          <h2 className="text-5xl font-bold text-gray-900 mb-8 leading-tight">
            Trasforma la tua visione<br />
            <span className="bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
              in successo globale
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-12 leading-relaxed">
            Il nostro sistema di assessment analizza 7 aree critiche attraverso 85 domande mirate, 
            fornendo una valutazione completa delle tue capacità export e un roadmap strategico 
            per conquistare i mercati internazionali.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          <div className="group bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-200 transition-colors">
              <BarChart3 className="w-7 h-7 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Analisi Approfondita</h3>
            <p className="text-gray-600 leading-relaxed">
              Assessment completo di 7 aree strategiche per una valutazione a 360° della tua propensione export
            </p>
          </div>

          <div className="group bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-teal-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-teal-200 transition-colors">
              <Target className="w-7 h-7 text-teal-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Report Personalizzato</h3>
            <p className="text-gray-600 leading-relaxed">
              Ricevi un report dettagliato con punteggi, visualizzazioni radar e raccomandazioni specifiche
            </p>
          </div>

          <div className="group bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-orange-200 transition-colors">
              <TrendingUp className="w-7 h-7 text-orange-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Piano d'Azione</h3>
            <p className="text-gray-600 leading-relaxed">
              Strategie concrete e prioritizzate per migliorare le tue performance sui mercati esteri
            </p>
          </div>

          <div className="group bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-green-200 transition-colors">
              <Globe className="w-7 h-7 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Visione Globale</h3>
            <p className="text-gray-600 leading-relaxed">
              Benchmark con le migliori pratiche internazionali per posizionarti competitivamente
            </p>
          </div>
        </div>

        {/* Assessment Characteristics and Areas - New Layout */}
        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          {/* Left Column - Characteristics */}
          <div className="bg-white rounded-3xl p-8 lg:p-10 shadow-sm border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Caratteristiche dell'Assessment</h3>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Il nostro strumento di valutazione è stato progettato per fornire un'analisi completa e accurata della propensione all'export della tua azienda.
            </p>
            
            <div className="space-y-4">
              {assessmentFeatures.map((feature, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  </div>
                  <span className="text-gray-700 leading-relaxed">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column - Areas */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-3xl p-8 lg:p-10">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-bold text-gray-900">7 Ambiti di Valutazione</h3>
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
            
            <div className="space-y-4">
              {assessmentAreas.map((area, index) => {
                const IconComponent = area.icon;
                return (
                  <div key={index} className="flex items-center space-x-4 p-3 bg-white/70 backdrop-blur-sm rounded-xl hover:bg-white/90 transition-all duration-200">
                    <div className={`w-10 h-10 ${area.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-gray-900 text-sm">{area.name}</h4>
                        <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded-full">
                          {area.questions} domande
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Detailed Areas Grid */}
        <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-sm border border-gray-100 mb-20">
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-12">Dettaglio Aree di Valutazione</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {assessmentAreas.map((area, index) => {
              const IconComponent = area.icon;
              return (
                <div key={index} className="group p-6 rounded-2xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all duration-300">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`w-12 h-12 ${area.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900">{area.name}</h4>
                      <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                        {area.questions} domande
                      </span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{area.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-12 text-white">
            <h3 className="text-3xl font-bold mb-6">Inizia il Tuo Assessment</h3>
            <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto leading-relaxed">
              Dedica 15-20 minuti per ottenere insights preziosi che trasformeranno 
              la tua strategia di internazionalizzazione
            </p>
            <button
              onClick={onStart}
              className="group bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 inline-flex items-center space-x-3"
            >
              <span>Inizia Assessment</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};