import React, { useState } from 'react';
import { Answer, AssessmentArea, Question } from '../types';
import { ChevronLeft, ChevronRight, CheckCircle, Clock } from 'lucide-react';

interface AssessmentFormProps {
  areas: AssessmentArea[];
  currentAreaIndex: number;
  answers: Record<string, Answer>;
  onAnswerChange: (questionId: string, answer: Answer) => void;
  onNext: () => void;
  onPrevious: () => void;
  onComplete: () => void;
  progress: number;
}

export const AssessmentForm: React.FC<AssessmentFormProps> = ({
  areas,
  currentAreaIndex,
  answers,
  onAnswerChange,
  onNext,
  onPrevious,
  onComplete,
  progress
}) => {
  const currentArea = areas[currentAreaIndex];
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const currentQuestion = currentArea.questions[currentQuestionIndex];

  const isAreaComplete = () => {
    return currentArea.questions.every(q => 
      !q.required || answers[q.id]?.value !== undefined
    );
  };

  const isLastArea = currentAreaIndex === areas.length - 1;
  const isLastQuestion = currentQuestionIndex === currentArea.questions.length - 1;

  const handleAnswerChange = (value: string | number | boolean, textValue?: string) => {
    onAnswerChange(currentQuestion.id, {
      questionId: currentQuestion.id,
      value,
      textValue
    });
  };

  const handleNextQuestion = () => {
    if (isLastQuestion) {
      if (isLastArea && isAreaComplete()) {
        onComplete();
      } else if (!isLastArea) {
        onNext();
        setCurrentQuestionIndex(0);
      }
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex === 0) {
      if (currentAreaIndex > 0) {
        onPrevious();
        setCurrentQuestionIndex(areas[currentAreaIndex - 1].questions.length - 1);
      }
    } else {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  // Fixed validation logic for boolean questions
  const isCurrentQuestionAnswered = () => {
    const answer = answers[currentQuestion.id];
    if (!answer) return false;
    
    // For boolean questions, both true and false are valid answers
    if (currentQuestion.category === 'boolean') {
      return answer.value === true || answer.value === false;
    }
    
    // For other question types, check if value exists and is not empty
    return answer.value !== undefined && answer.value !== '';
  };

  const renderQuestionInput = () => {
    const answer = answers[currentQuestion.id];

    switch (currentQuestion.category) {
      case 'text':
        return (
          <textarea
            value={answer?.textValue || ''}
            onChange={(e) => handleAnswerChange(e.target.value, e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
            rows={4}
            placeholder="Inserisci la tua risposta..."
          />
        );

      case 'boolean':
        return (
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => handleAnswerChange(true)}
              className={`flex-1 py-3 px-6 rounded-xl border-2 transition-all ${
                answer?.value === true
                  ? 'border-green-500 bg-green-50 text-green-700'
                  : 'border-gray-300 hover:border-green-300'
              }`}
            >
              Sì
            </button>
            <button
              type="button"
              onClick={() => handleAnswerChange(false)}
              className={`flex-1 py-3 px-6 rounded-xl border-2 transition-all ${
                answer?.value === false
                  ? 'border-red-500 bg-red-50 text-red-700'
                  : 'border-gray-300 hover:border-red-300'
              }`}
            >
              No
            </button>
          </div>
        );

      case 'slider':
        const sliderValue = typeof answer?.value === 'number' ? answer.value : 5;
        return (
          <div className="space-y-4">
            <div className="flex justify-between text-sm text-gray-500">
              <span>0 - Molto Basso</span>
              <span>10 - Eccellente</span>
            </div>
            <div className="relative">
              <input
                type="range"
                min="0"
                max="10"
                step="1"
                value={sliderValue}
                onChange={(e) => handleAnswerChange(Number(e.target.value))}
                className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                {Array.from({ length: 11 }, (_, i) => (
                  <span key={i}>{i}</span>
                ))}
              </div>
            </div>
            <div className="text-center">
              <span className="inline-flex items-center px-4 py-2 rounded-xl bg-blue-100 text-blue-800 font-semibold text-lg">
                Valore: {sliderValue}
              </span>
            </div>
          </div>
        );

      case 'multiple':
        return (
          <div className="space-y-3">
            {currentQuestion.options?.map((option, index) => (
              <button
                key={index}
                type="button"
                onClick={() => handleAnswerChange(option)}
                className={`w-full py-3 px-4 rounded-xl border-2 text-left transition-all ${
                  answer?.value === option
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-300 hover:border-blue-300'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  const questionProgress = ((currentQuestionIndex + 1) / currentArea.questions.length) * 100;
  const overallQuestionNumber = areas.slice(0, currentAreaIndex).reduce((sum, area) => sum + area.questions.length, 0) + currentQuestionIndex + 1;
  const totalQuestions = areas.reduce((sum, area) => sum + area.questions.length, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Progress Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-sm">{currentAreaIndex + 1}</span>
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">{currentArea.name}</h2>
                <p className="text-sm text-gray-600">{currentArea.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Clock className="w-4 h-4" />
                <span>Domanda {overallQuestionNumber} di {totalQuestions}</span>
              </div>
            </div>
          </div>
          
          {/* Overall Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
            <div 
              className="bg-gradient-to-r from-blue-600 to-teal-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          
          {/* Area Progress Bar */}
          <div className="w-full bg-gray-100 rounded-full h-1">
            <div 
              className="bg-blue-400 h-1 rounded-full transition-all duration-300"
              style={{ width: `${questionProgress}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Question Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 lg:p-12">
          {/* Question */}
          <div className="mb-8">
            <div className="flex items-start space-x-4 mb-6">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-blue-600 font-bold text-sm">{currentQuestionIndex + 1}</span>
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-3 leading-tight">
                  {currentQuestion.text}
                </h3>
                <div className="flex items-center space-x-4">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                    currentQuestion.type === 'quantitative' 
                      ? 'bg-purple-100 text-purple-700' 
                      : 'bg-green-100 text-green-700'
                  }`}>
                    {currentQuestion.type === 'quantitative' ? 'Valutazione Numerica' : 'Risposta Qualitativa'}
                  </span>
                  {currentQuestion.required && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                      Obbligatoria
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Answer Input */}
          <div className="mb-12">
            {renderQuestionInput()}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button
              onClick={handlePreviousQuestion}
              disabled={currentAreaIndex === 0 && currentQuestionIndex === 0}
              className="group flex items-center space-x-2 px-6 py-3 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              <span>Precedente</span>
            </button>

            <div className="flex items-center space-x-4">
              {/* Area completion indicator */}
              {isAreaComplete() && (
                <div className="flex items-center space-x-2 text-green-600">
                  <CheckCircle className="w-5 h-5" />
                  <span className="text-sm font-medium">Area completata</span>
                </div>
              )}
            </div>

            <button
              onClick={handleNextQuestion}
              disabled={currentQuestion.required && !isCurrentQuestionAnswered()}
              className="group flex items-center space-x-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-teal-600 text-white hover:from-blue-700 hover:to-teal-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>
                {isLastQuestion && isLastArea ? 'Completa Assessment' : 
                 isLastQuestion ? 'Prossima Area' : 'Prossima Domanda'}
              </span>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Area Questions Overview */}
        <div className="mt-8 bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Progresso Area: {currentArea.name}</h4>
          <div className="grid grid-cols-5 sm:grid-cols-10 lg:grid-cols-15 gap-2">
            {currentArea.questions.map((_, index) => (
              <div
                key={index}
                className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-medium transition-all cursor-pointer ${
                  index === currentQuestionIndex
                    ? 'bg-blue-600 text-white'
                    : answers[currentArea.questions[index].id]?.value !== undefined
                    ? 'bg-green-100 text-green-700'
                    : 'bg-gray-100 text-gray-500'
                }`}
                onClick={() => setCurrentQuestionIndex(index)}
              >
                {index + 1}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};