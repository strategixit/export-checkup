import { useState, useCallback } from 'react';
import { AppState, Answer, CompanyData, AssessmentResults } from '../types';
import { assessmentAreas } from '../data/questions';
import { calculateAreaScore, calculateOverallScore, generateRecommendations } from '../utils/calculations';

export const useAssessment = () => {
  const [state, setState] = useState<AppState>({
    currentStep: 'welcome',
    companyData: null,
    currentAreaIndex: 0,
    answers: {},
    results: null,
    progress: 0
  });

  const updateProgress = useCallback((answers: Record<string, Answer>) => {
    const totalQuestions = assessmentAreas.reduce((sum, area) => sum + area.questions.length, 0);
    const answeredQuestions = Object.keys(answers).length;
    return (answeredQuestions / totalQuestions) * 100;
  }, []);

  const startAssessment = useCallback(() => {
    setState(prev => ({ ...prev, currentStep: 'company-data' }));
  }, []);

  const setCompanyData = useCallback((data: CompanyData) => {
    setState(prev => ({ 
      ...prev, 
      companyData: data, 
      currentStep: 'assessment' 
    }));
  }, []);

  const setAnswer = useCallback((questionId: string, answer: Answer) => {
    setState(prev => {
      const newAnswers = { ...prev.answers, [questionId]: answer };
      const newProgress = updateProgress(newAnswers);
      
      return {
        ...prev,
        answers: newAnswers,
        progress: newProgress
      };
    });
  }, [updateProgress]);

  const nextArea = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentAreaIndex: Math.min(prev.currentAreaIndex + 1, assessmentAreas.length - 1)
    }));
  }, []);

  const previousArea = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentAreaIndex: Math.max(prev.currentAreaIndex - 1, 0)
    }));
  }, []);

  const completeAssessment = useCallback(() => {
    const areaScores: Record<string, number> = {};
    
    assessmentAreas.forEach(area => {
      areaScores[area.id] = calculateAreaScore(area, state.answers);
    });
    
    const overallScore = calculateOverallScore(areaScores);
    const recommendations = generateRecommendations(areaScores);
    
    const results: AssessmentResults = {
      overallScore,
      areaScores,
      recommendations,
      completionDate: new Date()
    };
    
    setState(prev => ({
      ...prev,
      results,
      currentStep: 'results',
      progress: 100
    }));
  }, [state.answers]);

  const restart = useCallback(() => {
    setState({
      currentStep: 'welcome',
      companyData: null,
      currentAreaIndex: 0,
      answers: {},
      results: null,
      progress: 0
    });
  }, []);

  return {
    state,
    startAssessment,
    setCompanyData,
    setAnswer,
    nextArea,
    previousArea,
    completeAssessment,
    restart
  };
};