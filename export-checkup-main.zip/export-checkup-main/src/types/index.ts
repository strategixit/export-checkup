export interface CompanyData {
  ragioneSociale: string;
  partitaIva: string;
  indirizzo: string;
  dimensioneAzienda: 'micro' | 'piccola' | 'media' | 'grande';
  fatturatoAnnuo?: number;
  numeroDipendenti?: number;
  numeroPaesiExport?: number;
  paesiExport?: string[];
}

export interface Question {
  id: string;
  text: string;
  type: 'qualitative' | 'quantitative';
  category: 'text' | 'multiple' | 'slider' | 'boolean';
  options?: string[];
  weight?: number;
  required: boolean;
}

export interface Answer {
  questionId: string;
  value: string | number | boolean;
  textValue?: string;
}

export interface AssessmentArea {
  id: string;
  name: string;
  description: string;
  questions: Question[];
  maxScore: number;
}

export interface AssessmentResults {
  overallScore: number;
  areaScores: Record<string, number>;
  recommendations: Record<string, string[]>;
  completionDate: Date;
}

export interface AppState {
  currentStep: 'welcome' | 'company-data' | 'assessment' | 'results';
  companyData: CompanyData | null;
  currentAreaIndex: number;
  answers: Record<string, Answer>;
  results: AssessmentResults | null;
  progress: number;
}